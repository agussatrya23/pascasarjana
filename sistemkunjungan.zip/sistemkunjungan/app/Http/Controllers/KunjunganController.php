<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Wargabinaans;

class KunjunganController extends Controller
{
    public function index()
    {
        return view('index');
    }

    public function search(Request $request)
    {
        $cari = $request->input('cari');

        if ($cari != null){
            $datacari = Wargabinaans::where('nama','LIKE','%'.$request->cari.'%')->get();
        }
        else  {
            $datacari = Wargabinaans::all();
        }
        return view('search', compact(
                'datacari'
        ));
    }
}
