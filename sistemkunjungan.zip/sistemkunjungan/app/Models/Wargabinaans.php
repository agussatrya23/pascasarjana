<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Wargabinaans extends Model
{
    use HasFactory;
    protected $table = "wargabinaans";
    protected $fillable = ['id','nama','alamat','wisma','kamar','status','akhirhukuman','keterangan'];
}
