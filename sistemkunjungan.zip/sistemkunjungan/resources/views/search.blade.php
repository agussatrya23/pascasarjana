<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="{{asset('assets/style.css')}}">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

    <title>Sistem Kunjungan</title>
  </head>
  <body>
        <div class="container">
            <div class="header">
                <div class="logo-top">
                    <img src="{{asset('assets/logo.jpg')}}" alt="">
                </div>
                <div class="title-search">
                    <h2>LEMBAGA PEMASYARAKATAN KHUSUS NARKOTIKA</h2>
                    <h2>KELAS IIA BANGLI</h2>
                </div>
            </div>
            <div class="content">
            <table class="table table-bordered">
                <thead class='table-primary'>
                    <tr>
                    <th scope="col">Nama Warga Binaan</th>
                    <th scope="col">Tanggal Lahir</th>
                    <th scope="col">Wisma</th>
                    <th scope="col">Kamar</th>
                    <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($datacari as $data)
                        <tr>
                            <td style="width: 25%">{{ $data->nama }}</td>
                            <td style="width: 15%">{{ $data->alamat}}</td>
                            <td style="width: 10%">{{ $data->wisma}}</td>
                            <td style="width: 10%">{{ $data->kamar}}</td>
                            @php
                                $a=$data->status;
                                if($a == 'Bisa'){
                                    echo '<td style="width: 40%"><i class="bi bi-check-circle-fill" style="color: #0f0"></i>Boleh Menerima Titipan Uang & Barang</td>';
                                }
                                else if($a == 'Uang'){
                                    echo '<td style="width: 40%"><i class="bi bi-cash" style="color: rgb(255, 217, 0)"></i>Hanya Boleh Menerima Titipan Uang</td>';
                                }
                                else{
                                    echo '<td style="width: 40%"><i class="bi bi-x-circle-fill " style="color: #f00"></i>Tidak Boleh Menerima Titipan Uang dan Barang Karena Melanggar Tata Tertib</td>';
                                }
                            @endphp
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center">
                                Data tidak ditemukan
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="info">
            <h5>Barang yang dilarang masuk kedalam Lapas</h5>
            <ol class="list-group-numbered">
                <li>Alat Komunikasi</li>
                <li>Minuman Keras dan Narkoba</li>
                <li>Alat Perekam</li>
                <li>Senjata Api dan Senjata Tajam</li>
                <li>Benda Logam, Beling, dan Kaca</li>
            </ol>
        </div>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>
